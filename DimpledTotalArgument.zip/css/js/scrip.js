document.getElementById("botãoEnviar").  addEventListener("click",validaFormulario)

function validaFomulario(){

if(document.getElementById("nome").value !="" && document.getElementById("email").value !=""){  Prontinho! você receberá as novidades por email. 
  
}else{
alert("Por favor, preencha os campos nome e email!")
 }
}
  

